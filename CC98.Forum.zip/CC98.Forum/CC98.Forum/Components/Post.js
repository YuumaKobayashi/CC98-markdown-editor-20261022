"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var react_router_dom_1 = require("react-router-dom");
var RouteComponent = (function (_super) {
    __extends(RouteComponent, _super);
    function RouteComponent(props, context) {
        var _this = _super.call(this, props, context) || this;
        _this.match = props.match;
        return _this;
    }
    return RouteComponent;
}(React.Component));
exports.RouteComponent = RouteComponent;
var Post = (function (_super) {
    __extends(Post, _super);
    function Post() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Post.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { className: "center" },
                React.createElement(PostTopic, null),
                React.createElement(Reply, null)));
    };
    return Post;
}(RouteComponent));
exports.Post = Post;
var Reply = (function (_super) {
    __extends(Reply, _super);
    function Reply() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Reply.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { className: "center", style: { width: "1140px" } },
                React.createElement(Replier, null),
                React.createElement(ReplyContent, null)));
    };
    return Reply;
}(RouteComponent));
exports.Reply = Reply;
var Replier = (function (_super) {
    __extends(Replier, _super);
    function Replier(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            imgUrl: "/images/authorImg.jpg",
            timeImgUrl: "/images/clock.jpg",
            userName: "VayneTian",
            replyTime: Date(),
            topicsNumber: 999,
            level: 2,
        };
        return _this;
    }
    Replier.prototype.render = function () {
        return React.createElement("div", { className: "replyRoot" },
            React.createElement("div", { className: "row", style: { width: "1140px", display: "flex" } },
                React.createElement("div", { id: "authorImg" },
                    React.createElement("img", { src: this.state.imgUrl })),
                React.createElement("div", { className: "column", id: "rpymes" },
                    React.createElement("div", { className: "row", id: "replierMes" },
                        React.createElement("div", { style: { marginLeft: "10px" } },
                            React.createElement("span", null,
                                this.state.level,
                                "L")),
                        React.createElement("div", { className: "rpyClrodd", style: { marginLeft: "10px" } }, this.state.userName),
                        React.createElement("div", { id: "topicsNumber", style: { marginLeft: "10px" } },
                            "\u8D34\u6570   ",
                            React.createElement("span", { className: "rpyClrodd" }, this.state.topicsNumber),
                            " ")),
                    React.createElement("div", { className: "row" },
                        React.createElement("div", { id: "clockimg" },
                            React.createElement("img", { src: this.state.timeImgUrl })),
                        React.createElement("div", null,
                            React.createElement("span", { className: "timeProp" }, this.state.replyTime)))),
                React.createElement("div", { id: "operation" },
                    React.createElement("button", { className: "operation" }, "\u5F15\u7528"),
                    React.createElement("button", { className: "operation" }, "\u7F16\u8F91"),
                    React.createElement("button", { className: "operation" }, "\u79C1\u4FE1"),
                    React.createElement("button", { className: "operation" }, "\u4E3E\u62A5"),
                    React.createElement("button", { className: "operation" }, "\u53EA\u770B\u6B64\u7528\u6237"))));
    };
    return Replier;
}(RouteComponent));
exports.Replier = Replier;
var PostTopic = (function (_super) {
    __extends(PostTopic, _super);
    function PostTopic(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            imgUrl: "/images/ads.jpg"
        };
        return _this;
    }
    PostTopic.prototype.render = function () {
        return React.createElement(react_router_dom_1.BrowserRouter, null,
            React.createElement("div", { className: "root" },
                React.createElement("div", { className: "essay" },
                    React.createElement(AuthorMessage, null),
                    React.createElement(TopicTitle, null),
                    React.createElement("div", { id: "ads" },
                        React.createElement("img", { src: this.state.imgUrl }))),
                React.createElement(TopicContent, null),
                React.createElement(TopicGood, null),
                React.createElement(TopicVote, null)));
    };
    return PostTopic;
}(RouteComponent));
exports.PostTopic = PostTopic;
var AuthorMessage = (function (_super) {
    __extends(AuthorMessage, _super);
    function AuthorMessage(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            userName: "Mana",
            fansNumber: 233,
            imgUrl: "/images/authorImg.jpg"
        };
        return _this;
    }
    AuthorMessage.prototype.render = function () {
        return React.createElement("div", { className: "row", id: "authormes" },
            React.createElement("div", { id: "authorImg" },
                React.createElement("img", { src: this.state.imgUrl })),
            React.createElement("div", { className: "column" },
                React.createElement("div", { className: "row" },
                    React.createElement("div", { id: "authorName" },
                        React.createElement("p", null, this.state.userName)),
                    React.createElement("div", { id: "fans" },
                        React.createElement("p", null, "\u7C89\u4E1D")),
                    React.createElement("div", { id: "authorFans" },
                        React.createElement("p", null, this.state.fansNumber))),
                React.createElement("div", { className: "row" },
                    React.createElement("button", { id: "watch" }, "\u5173\u6CE8"),
                    React.createElement("button", { id: "email" }, "\u79C1\u4FE1"))));
    };
    return AuthorMessage;
}(RouteComponent));
exports.AuthorMessage = AuthorMessage;
var TopicTitle = (function (_super) {
    __extends(TopicTitle, _super);
    function TopicTitle(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            isNotice: true,
            isTop: true,
            title: "这是一个长长啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊啊的标题",
            tag: "女装/开车",
            time: "2017.8.12",
            likeNumber: 666,
            unlikeNumber: 233,
            viewTimes: 2366
        };
        return _this;
    }
    TopicTitle.prototype.render = function () {
        return React.createElement("div", { id: "title" },
            React.createElement("div", { className: "column", style: { width: "520px" } },
                React.createElement("div", { id: "essay1" },
                    React.createElement("div", { id: "title1" },
                        " ",
                        React.createElement("span", { className: "titleProp" }, this.state.isTop ? "【置顶】" : ""),
                        React.createElement("span", { className: "titleProp" },
                            this.state.isNotice ? "【公告】" : "",
                            " "),
                        React.createElement("span", { id: "essayTitle" }, this.state.title))),
                React.createElement("div", { className: "row", id: "essayProp" },
                    React.createElement("div", { id: "essayGrow" },
                        React.createElement("div", { id: "tags" },
                            React.createElement("span", { className: "tagProp tagSize" },
                                "\u6807\u7B7E\uFF1A ",
                                this.state.tag),
                            React.createElement("span", { className: "tagProp" })),
                        React.createElement("div", { id: "time" },
                            React.createElement("img", { src: "/images/clock.jpg", style: { marginTop: "3px" } }),
                            " ",
                            React.createElement("span", { className: "timeProp tagSize" }, this.state.time)),
                        React.createElement("div", { id: "viewtimes" },
                            React.createElement("span", { className: "viewProp" }, "\u2605~\u2605 "),
                            " ",
                            React.createElement("span", { className: "timeProp tagSize" },
                                this.state.viewTimes,
                                "\u6B21"))))),
            React.createElement("div", { className: "column", style: { width: "100px" } },
                React.createElement("div", { className: "row", style: { marginTop: "20px" } },
                    React.createElement("div", { id: "like" },
                        React.createElement("span", null,
                            React.createElement("button", { id: "onlike" }, "\u2730"),
                            "  \u6536\u85CF\u6587\u7AE0"))),
                React.createElement("div", { className: "row", style: { marginTop: "20px" } },
                    React.createElement("div", { id: "liked" },
                        React.createElement("img", { src: "/images/like.jpg" }),
                        React.createElement("span", { className: "timeProp tagSize" }, this.state.likeNumber)),
                    React.createElement("div", { id: "unliked" },
                        React.createElement("img", { src: "/images/unlike.jpg" }),
                        React.createElement("span", { className: "timeProp tagSize" }, this.state.unlikeNumber)))));
    };
    return TopicTitle;
}(RouteComponent));
exports.TopicTitle = TopicTitle;
var TopicContent = (function (_super) {
    __extends(TopicContent, _super);
    function TopicContent(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            likeNumber: 666,
            unlikeNumber: 233,
            signature: "where there is a will, there is a way.",
            content: "央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。</p><p>央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。",
        };
        return _this;
    }
    TopicContent.prototype.render = function () {
        return React.createElement("div", { className: "content" },
            React.createElement("div", { className: "substance" },
                React.createElement("p", null, this.state.content)),
            React.createElement("div", { className: "signature" }, this.state.signature),
            React.createElement("div", { className: "comment" },
                React.createElement("div", { id: "commentlike" },
                    React.createElement("button", { className: "commentbutton" }, "\u2730"),
                    "  \u6536\u85CF\u6587\u7AE0"),
                React.createElement("div", { id: "commentliked" },
                    React.createElement("img", { src: "/images/like.jpg" }),
                    React.createElement("span", { className: "commentProp" },
                        " ",
                        this.state.likeNumber)),
                React.createElement("div", { id: "commentunliked" },
                    React.createElement("img", { src: "/images/unlike.jpg" }),
                    React.createElement("span", { className: "commentProp" },
                        " ",
                        this.state.unlikeNumber)),
                React.createElement("div", { id: "commentlike" },
                    " ",
                    React.createElement("button", { className: "commentbutton" }, "   \u8BC4\u5206"),
                    React.createElement("button", { className: "commentbutton" }, "   \u7F16\u8F91"))));
    };
    return TopicContent;
}(RouteComponent));
exports.TopicContent = TopicContent;
var ReplyContent = (function (_super) {
    __extends(ReplyContent, _super);
    function ReplyContent(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            likeNumber: 2424,
            unlikeNumber: 4433,
            signature: "Lovelive!",
            content: "央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。</p><p>央视网消息：7月26日至27日，习近平在省部级主要领导干部专题研讨班开班式上强调，党的十八大以来的5年，是党和国家发展进程中很不平凡的5年。我们加强党对意识形态工作的领导，巩固了全党全社会思想上的团结统一。党的十八大以来，面对意识形态领域日益错综复杂的形势，习总书记发表了一系列重要讲话，深刻阐述了意识形态工作的重大理论和现实问题。本图解梳理了相关重要论述以及十八大以来各领域工作成绩，以飨读者。",
        };
        return _this;
    }
    ReplyContent.prototype.render = function () {
        return React.createElement("div", { className: "root" },
            React.createElement("div", { className: "content" },
                React.createElement("div", { className: "substance" },
                    React.createElement("p", null, this.state.content)),
                React.createElement("div", { className: "signature" }, this.state.signature),
                React.createElement("div", { className: "comment" },
                    React.createElement("div", { id: "commentliked" },
                        React.createElement("img", { src: "/images/like.jpg" }),
                        React.createElement("span", { className: "commentProp" },
                            " ",
                            this.state.likeNumber)),
                    React.createElement("div", { id: "commentunliked" },
                        React.createElement("img", { src: "/images/unlike.jpg" }),
                        React.createElement("span", { className: "commentProp" },
                            " ",
                            this.state.unlikeNumber)),
                    React.createElement("div", { id: "commentlike" },
                        " ",
                        React.createElement("button", { className: "commentbutton" }, "   \u8BC4\u5206")))));
    };
    return ReplyContent;
}(RouteComponent));
exports.ReplyContent = ReplyContent;
var TopicGood = (function (_super) {
    __extends(TopicGood, _super);
    function TopicGood(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            userName: "Mana",
            grade: 10,
            reward: 20,
            credit: "6666炒鸡赞",
            imgUrl: "/images/authorImg.jpg"
        };
        return _this;
    }
    TopicGood.prototype.render = function () {
        return React.createElement("div", { className: "good" },
            React.createElement("div", { id: "userImage" },
                React.createElement("img", { src: this.state.imgUrl }),
                " "),
            React.createElement("div", { id: "userName" },
                React.createElement("span", null, this.state.userName)),
            React.createElement("div", { id: "grades" },
                React.createElement("span", null, "\u8BC4\u5206 "),
                React.createElement("span", { id: "grade" },
                    "+",
                    this.state.grade)),
            React.createElement("div", { id: "reward" },
                React.createElement("span", null, "\u8D4F\u91D1 "),
                React.createElement("span", { id: "money" }, this.state.reward),
                React.createElement("span", null, "\u8BBA\u575B\u5E01")),
            React.createElement("div", { id: "credit" },
                React.createElement("span", null, this.state.credit)));
    };
    return TopicGood;
}(RouteComponent));
exports.TopicGood = TopicGood;
var TopicVote = (function (_super) {
    __extends(TopicVote, _super);
    function TopicVote(props, content) {
        var _this = _super.call(this, props, content) || this;
        _this.state = {
            option: "我认为他说的很对",
            votes: 60,
            totalVotes: 220,
            voted: false,
        };
        return _this;
    }
    TopicVote.prototype.render = function () {
        return React.createElement("div", { className: "vote" },
            React.createElement("div", { className: "row" },
                React.createElement("input", { id: "checkbox", type: "checkbox" }),
                " ",
                React.createElement("span", { id: "option", style: { marginLeft: "15px" } },
                    this.state.option,
                    " ")),
            React.createElement("div", { className: "row" },
                React.createElement("div", { className: "progress" },
                    React.createElement("div", { className: "voteResult" })),
                React.createElement("span", { style: { marginLeft: "15px" } }, this.state.votes),
                React.createElement("span", null,
                    " (",
                    this.state.votes / this.state.totalVotes * 100,
                    "%)")),
            React.createElement("div", { style: { marginLeft: "20px" } }, this.state.voted ? React.createElement("span", null, "\u4F60\u5DF2\u7ECF\u6295\u8FC7\u7968\u5566") : React.createElement("button", { className: "operation" }, "\u6295\u7968")));
    };
    return TopicVote;
}(RouteComponent));
exports.TopicVote = TopicVote;
//# sourceMappingURL=post.js.map