﻿import { match } from "react-router";
import { MessageMatch } from '../Match/Match'
/**
 * 热门话题
 */
export class HotTopic {
    /**
     *作者
     */
    authorName: string;
    /**
     * 标题
     */
    title: string;
    likeImgUrl: "/images/like.jpg";
    unlikeImgUrl: "/images/unlike.jpg";
    commentImgUrl: "/images/comment.jpg";
    constructor(title, author) {
        this.title = title;
        this.authorName = author;
    }
}
export class ListPagerProps {
    pageNumber: number;
    match:match<MessageMatch>;
}
export class topicSet {
    items;
}