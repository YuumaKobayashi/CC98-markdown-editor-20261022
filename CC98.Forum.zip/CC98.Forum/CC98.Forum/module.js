"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var State = require("./States/AppState");
var React = require("react");
var List_1 = require("./Components/List");
var react_router_dom_1 = require("react-router-dom");
function getData() {
    return __awaiter(this, void 0, void 0, function () {
        var hottopics, response, data, i, items;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    hottopics = [];
                    return [4 /*yield*/, fetch('http://api.cc98.org/Topic/Hot')];
                case 1:
                    response = _a.sent();
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    for (i = 0; i < 10; i++) {
                        hottopics[i] = new State.TopicTitleAndContentState(data[i].title, data[i].authorName || '匿名');
                    }
                    items = hottopics.map(convertHotTopic);
                    return [2 /*return*/, items];
            }
        });
    });
}
exports.getData = getData;
function getPager(curPage) {
    var pages = [];
    if (curPage == undefined || curPage == 1 || curPage == 2) {
        pages[0] = new State.PagerState(1);
        pages[1] = new State.PagerState(2);
        pages[2] = new State.PagerState(3);
        pages[3] = new State.PagerState(4);
        pages[4] = new State.PagerState(5);
    }
    else {
        pages[0] = new State.PagerState(curPage - 2);
        pages[1] = new State.PagerState(curPage - 1);
        pages[2] = new State.PagerState(curPage);
        pages[3] = new State.PagerState(curPage + 1);
        pages[4] = new State.PagerState(curPage + 2);
    }
    return pages;
}
exports.getPager = getPager;
function getBoardTopic(curPage) {
    return __awaiter(this, void 0, void 0, function () {
        var startPage, endPage, boardtopics, response, data, i;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    startPage = (curPage - 1) * 10 + 1;
                    endPage = curPage * 10;
                    boardtopics = [];
                    return [4 /*yield*/, fetch('http://api.cc98.org/Topic/Board/493', { headers: { Range: "bytes=" + startPage + "-" + endPage } })];
                case 1:
                    response = _a.sent();
                    return [4 /*yield*/, response.json()];
                case 2:
                    data = _a.sent();
                    for (i = 0; i < 10; i++) {
                        boardtopics[i] = new State.TopicTitleAndContentState(data[i].title, data[i].authorName || '匿名');
                    }
                    return [2 /*return*/, boardtopics];
            }
        });
    });
}
exports.getBoardTopic = getBoardTopic;
function convertHotTopic(item) {
    return React.createElement(List_1.TopicTitleAndContent, { title: item.title, authorName: item.authorName, likeImgUrl: "/images/like.jpg", unlikeImgUrl: "/images/unlike.jpg", commentImgUrl: "/images/comment.jpg" });
}
exports.convertHotTopic = convertHotTopic;
function pageNumber(pageNumber) {
    var pageUrl = "/list/" + pageNumber.pageNumber;
    return React.createElement("div", null,
        " ",
        React.createElement(react_router_dom_1.Link, { className: "pager", style: {
                width: "30px",
                height: "25px"
            }, to: pageUrl }, pageNumber.pageNumber));
}
exports.pageNumber = pageNumber;
//# sourceMappingURL=module.js.map